var buttonColors = ["red", "blue", "green", "yellow"];

var gamePattern = [];

var userClickedPattern = [];

var started = false;

var level = 0;


$(document).keydown(function(event) {
  if (started === false) {
    nextSequence();
    started = true;
  }

});

$(".btn").click(function() {
  var userChosenColor = $(this).attr("id");
  userClickedPattern.push(userChosenColor);

  playSound(userChosenColor);

  animatePress(userChosenColor);

  var lastIndex = userClickedPattern.length - 1;

  checkAnswer(lastIndex);

});

function checkAnswer(currentLevel) {
  console.log({
    gamePattern
  });
  console.log({
    userClickedPattern
  });

  if (userClickedPattern[currentLevel] === gamePattern[currentLevel]) { // if they meet than success,
    console.log("success");

    if (userClickedPattern.length === gamePattern.length) { // if lengths match, then reset.

      setTimeout(function() { // but when tehy match, userChosenColor resets to empty but gamepattern is too far ahead, so i need to click last step instead of build up to new one.
        nextSequence()
      }, 1000);

    }

  } else {
    $("body").addClass("game-over");
    setTimeout(function() { // but when tehy match, userChosenColor resets to empty but gamepattern is too far ahead, so i need to click last step instead of build up to new one.
      $("body").removeClass("game-over");
    }, 200);

    var errorSound = "wrong";
    playSound(errorSound);

    $("#level-title").text("Game Over, Press Any Key to Restart");

    startOver();
    console.log("wrong");
  }

}

function startOver () {
  level = 0;
  gamePattern=[];
  started= false;
}

function nextSequence() {
  userClickedPattern = [];

  var randomNumber = Math.round(Math.random() * 3);
  var randomChosenColor = buttonColors[randomNumber];
  gamePattern.push(randomChosenColor);

  $("#" + randomChosenColor).fadeIn(100).fadeOut(100).fadeIn(100);

  playSound(randomChosenColor);

  level++;
  $("#level-title").html("Level " + level);

}

function playSound(name) {

  var audio = new Audio("sounds/" + name + ".mp3");
  audio.play();

}

function animatePress(currentColor) {
  // var activeButton = $("." + currentColor);
  // activeButton.addClass("pressed");
  $("#" + currentColor).addClass("pressed");

  setTimeout(function() {
    $("#" + currentColor).removeClass("pressed");
  }, 100);

};

// For JS code, read right to left when translating to English.
// JS always reads top to bottom, order matters! This is with lines and blocks of code!

// When what i UserClickedPattern = gamePattern, then i continue to next array of gamepattern starting from 0 in
// userClickedPattern.
// If the dont match, then i get an error message.
//when the number of array items or indices are the same, then reset userClickedPattern so that you have to built up the new pattern thats now built in gamePattern.
